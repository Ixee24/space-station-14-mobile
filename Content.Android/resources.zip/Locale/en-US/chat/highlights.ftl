# Command
highlights-captain = Captain, "Cap", "Bridge", "Command"
highlights-headofpersonnel = Head Of Personnel, "HoP", Service, "Serv", "Bridge", "Command"
highlights-chiefengineer = Chief Engineer, "CE", Engineering, "Engi", "Bridge", "Command"
highlights-chiefmedicalofficer = Chief Medical Officer, "CMO", Medbay, Medical, "Med", "Bridge", "Command"
highlights-headofsecurity = Head of Security, "HoS", Armory, Security, "Sec", "Bridge", "Command"
highlights-quartermaster = Quartermaster, "QM", Cargo, Supply, "Bridge", "Command"
highlights-researchdirector = Research Director, "RD", Science, "Sci", "Bridge", "Command"

# Security
highlights-detective = Detective, "Det", Armory, Security, "Sec"
highlights-securitycadet = Security Cadet, Secoff, Cadet, Armory, Security, "Sec"
highlights-securityofficer = Security Officer, Secoff, Officer, Armory, Security, "Sec"
highlights-warden = Warden, "Ward", Brig, Genpop, Jail, "Prison", Armory, Security, "Sec"

# Cargo
highlights-cargotechnician = Cargo Technician, Cargo Tech, "Cargo", Supply
highlights-salvagespecialist = Salvage Specialist, Salvager, Salvage, "Salv", "Cargo", Supply

# Engineering
highlights-atmospherictechnician = Atmospheric Technician, Atmos Tech, Atmospheric, Engineering, "Atmos", "Engi"
highlights-stationengineer = Station Engineer, Engineer, Engineering, "Engi", "Engis"
highlights-technicalassistant = Technical Assistant, Tech Assistant, "TA", Engineering, "Engi"

# Medical
highlights-chemist = Chemist, Chemistry, "Chem", Medbay, Medical, "Med"
highlights-medicaldoctor = Medical Doctor, Doctor, "Doc", Medbay, Medical, "Med"
highlights-medicalintern = Medical Intern, Intern, Medbay, Medical, "Med"
highlights-paramedic = Paramedic, "Para", "Medic", Medbay, Medical, "Med"

# Science
highlights-researchassistant = Research Assistant, "RA", Science, "Sci"
highlights-scientist = Scientist, Science, "Sci"

# Service
highlights-bartender = Bartender, Barkeeper, Barkeep, "Bar", Service, "Serv"
highlights-botanist = Botanist, Botany, Hydroponics, Service, "Serv"
highlights-chaplain = Chaplain, Chapel, Service, "Serv"
highlights-chef = Chef, "Cook", Kitchen, Service, "Serv"
highlights-clown = Clown, Theatre, Theater, Service, "Serv"
highlights-janitor = Janitor, "Jani", Service, "Serv"
highlights-lawyer = Lawyer, Attorney, "Law", Service, "Serv"
highlights-librarian = Librarian, Library, Service, "Serv"
highlights-mime = Mime, Theatre, Theater, Service, "Serv"
highlights-musician = Musician, Theatre, Theater, Service, "Serv"
highlights-serviceworker = Service Worker, Service, "Serv"

# Station-specific
highlights-psychologist = Psychologist, Psychology, "Psych", Medbay, Medical, "Med"
highlights-reporter = Reporter, Journalist, Newsroom, News, Service, "Serv"
highlights-tramdriver = Tram Driver, Tram, "Driver", Service, "Serv"

# Silicon
highlights-borg = Cyborg, Silicon, Borg, Robotics, "Robot", "Law", "Laws", "Lawset"
highlights-stationai = Station AI, Silicon, "AI", "sAI", "Law", "Laws", "Lawset"

# Civilian
highlights-passenger = Passenger, Greyshirt, Grayshirt, Greytider, Graytider, Tider, Civilian, Civie, Civvie, Civvy
highlights-visitor = Visitor, Civilian, Civie, Civvie, Civvy

# Central Command
highlights-centralcommandofficial = Central Command Official, "Official", "Central Command", CentCom, CentComm, "CC"
highlights-cburn = CBURN
highlights-deathsquad = Death Squad, Deathsquad
highlights-ertleader = Leader, "ERT", "Emergency Response Team"
highlights-ertchaplain = Chaplain, "ERT", "Emergency Response Team"
highlights-ertengineer = Engineer, "Engi", "ERT", "Emergency Response Team"
highlights-ertsecurity = Security, "ERT", "Emergency Response Team"
highlights-ertmedical = "Medic", "ERT", "Emergency Response Team"
highlights-ertjanitor = Janitor, "Jani", "ERT", "Emergency Response Team"
