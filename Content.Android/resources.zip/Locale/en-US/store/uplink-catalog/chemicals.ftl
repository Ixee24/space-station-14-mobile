# Chemicals

uplink-hypopen-name = Hypopen
uplink-hypopen-desc = A chemical hypospray disguised as a pen, capable of instantly injecting up to 10u of reagents. Takes a moment to refill it, so plan accordingly!

uplink-hypodart-name = Hypodart
uplink-hypodart-desc = A seemingly unremarkable dart with a hidden 10u liquid reserve. Instantly injects into a target when thrown and pierces hardsuits.

uplink-chemistry-kit-name = Chemical Synthesis Kit
uplink-chemistry-kit-desc = A starter kit for the aspiring chemist, includes two vials of vestine for all your criminal needs!

uplink-zombie-bundle-name = Syndicate Zombie Bundle
uplink-zombie-bundle-desc = An all-in-one kit for unleashing the undead upon a station. Take the Ambuzol+ pill for the cure!

uplink-nocturine-chemistry-bottle-name = Nocturine Bottle
uplink-nocturine-chemistry-bottle-desc = A chemical that puts your target straight to sleep. Frequently bought with the Hypodarts or Hypopen.

uplink-combat-medkit-name = Combat Medical Kit
uplink-combat-medkit-desc = A medkit made for fixing combat injuries.

uplink-combat-medipen-name = Combat Medipen
uplink-combat-medipen-desc = A single-use medipen containing chemicals that regenerate most types of damage.

uplink-stimpack-name = Hyperzine Injector
uplink-stimpack-desc = The legendary chemical produced by Donk Co. for the Syndicate. Injecting yourself with this will increase your run speed and let you recover from stuns faster for 60 seconds.

uplink-stimkit-name = Hyperzine Injector Kit
uplink-stimkit-desc = A standard medkit containing 6 hyperzine microinjectors. Each dose lasts for 30 seconds.

uplink-cigarettes-name = Syndicate Smokes Packet
uplink-cigarettes-desc = Elite cigarettes for elite agents. Infused with omnizine for when you need to do more than calm your nerves.

uplink-meds-bundle-name = Interdyne Medical Bundle
uplink-meds-bundle-desc = An assortment of autoinjectors and combat medkits to cover for every possible situation. Contains an elite compact defibrillator that can be used as a weapon.
