humanoid-profile-editor-randomize = Randomize
humanoid-profile-editor-randomize-unlocked-button = Randomize unlocked
humanoid-profile-editor-randomize-name-button = Name
humanoid-profile-editor-randomize-species-button = Species
humanoid-profile-editor-randomize-age-button = Age
humanoid-profile-editor-randomize-sex-button = Sex
humanoid-profile-editor-randomize-skin-button = Skin color
humanoid-profile-editor-randomize-eye-button = Eye color
humanoid-profile-editor-randomize-markings-button = Markings
humanoid-profile-editor-name-label = Name:
humanoid-profile-editor-appearance-tab = Appearance
humanoid-profile-editor-clothing = Show clothing
humanoid-profile-editor-clothing-show = Show
humanoid-profile-editor-sex-label = Sex:
humanoid-profile-editor-sex-male-text = Male
humanoid-profile-editor-sex-female-text = Female
humanoid-profile-editor-sex-unsexed-text = None
humanoid-profile-editor-voice-label = Voice:
humanoid-profile-editor-age-label = Age:
humanoid-profile-editor-skin-color-label = Skin color:
humanoid-profile-editor-species-label = Species:
humanoid-profile-editor-randomizer-lock-tooltip = Prevents the value from being randomized
humanoid-profile-editor-pronouns-label = Pronouns:
humanoid-profile-editor-pronouns-male-text = He / Him
humanoid-profile-editor-pronouns-female-text = She / Her
humanoid-profile-editor-pronouns-epicene-text = They / Them
humanoid-profile-editor-pronouns-neuter-text = It / Its
humanoid-profile-editor-import-button = Import
humanoid-profile-editor-export-button = Export
humanoid-profile-editor-export-image-button = Export image
humanoid-profile-editor-open-image-button = Open images
humanoid-profile-editor-save-button = Save
humanoid-profile-editor-reset-button = Reset
humanoid-profile-editor-spawn-priority-label = Spawn priority:
humanoid-profile-editor-eyes-label = Eye color:
humanoid-profile-editor-jobs-tab = Jobs
humanoid-profile-editor-preference-unavailable-stay-in-lobby-button = Stay in lobby if preference unavailable.
humanoid-profile-editor-preference-unavailable-spawn-as-overflow-button = Be {INDEFINITE($overflowJob)} {$overflowJob} if preference unavailable.
humanoid-profile-editor-preference-jumpsuit = Jumpsuit
humanoid-profile-editor-preference-jumpskirt = Jumpskirt
humanoid-profile-editor-preference-backpack = Backpack
humanoid-profile-editor-preference-satchel = Satchel
humanoid-profile-editor-preference-duffelbag = Duffelbag
humanoid-profile-editor-guidebook-button-tooltip = Click for more info

# Spawn priority
humanoid-profile-editor-preference-spawn-priority-none = None
humanoid-profile-editor-preference-spawn-priority-arrivals = Arrivals
humanoid-profile-editor-preference-spawn-priority-cryosleep = Cryosleep

humanoid-profile-editor-jobs-amount-in-department-tooltip = Jobs in the {$departmentName} department
humanoid-profile-editor-department-jobs-label = {$departmentName} jobs
humanoid-profile-editor-antags-tab = Antags
humanoid-profile-editor-antag-preference-yes-button = Yes
humanoid-profile-editor-antag-preference-no-button = No

humanoid-profile-editor-job-priority-high-button = High
humanoid-profile-editor-job-priority-medium-button = Medium
humanoid-profile-editor-job-priority-low-button = Low
humanoid-profile-editor-job-priority-never-button = Never
humanoid-profile-editor-naming-rules-warning = Warning: Offensive or LRP IC names and descriptions will lead to admin intervention on this server. Read our \[Rules\] for more.
humanoid-profile-editor-markings-tab = Markings
humanoid-profile-editor-flavortext-tab = Description

# Traits
humanoid-profile-editor-traits-tab = Traits
humanoid-profile-editor-no-traits = No traits available

humanoid-profile-editor-trait-count-hint = Points available: [{$current}/{$max}]

trait-category-disabilities = Disabilities
trait-category-speech = Speech traits
trait-category-quirks = Quirks

# Voices
humanoid-profile-editor-voice-masculine = Masculine
humanoid-profile-editor-voice-feminine = Feminine
humanoid-profile-editor-voice-neutral = Neutral
humanoid-profile-editor-voice-none = Unnamed Voice
