skeleton-suffix = ACK ACK!
