action-speech-spell-forcewall = TARCOL MINTI ZHERI
action-speech-spell-knock = AULIE OXIN FIERA
action-speech-spell-smite = EI NATH!
action-speech-spell-summon-magicarp = AIE KHUSE EU
action-speech-spell-summon-guns = YOR'NEE VES-KORFA
action-speech-spell-summon-magic = RYGOIN FEMA-VERECO
action-speech-spell-mind-swap = GIN'YU CAPAN!
action-speech-spell-cluwne = !KNOH
action-speech-spell-slip = SLEE PARRI!
action-speech-spell-charge = DI'RI CEL!

action-speech-spell-fireball-1 = ONI'SOMA!
action-speech-spell-fireball-2 = FYIR'BHAL!
action-speech-spell-fireball-3 = TEU A'SHIES!
action-speech-spell-fireball-4 = B'COEM THOASHT!
action-speech-spell-fireball-5 = KA'E BEUME!
