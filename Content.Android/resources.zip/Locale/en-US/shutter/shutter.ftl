shutter-rattle = *rattle rattle*
